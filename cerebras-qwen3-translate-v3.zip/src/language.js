function execute() {
  return Response.success([
    { id: "vi", name: "Tiếng Việt" },
    { id: "en", name: "English" },
    { id: "zh", name: "中文 (Chinese)" },
    { id: "ja", name: "日本語 (Japanese)" },
    { id: "ko", name: "한국어 (Korean)" }
  ]);
}
