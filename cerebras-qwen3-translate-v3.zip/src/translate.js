function execute(text, fromLang, toLang) {
  // Đọc config - key đúng là "api_keys" (theo format Vbook)
  var apiKey = config["api_keys"] || "";
  var model  = config["model"]    || "qwen-3-32b";
  var temp   = parseFloat(config["temp"]) || 0.3;

  if (!apiKey || apiKey.trim() === "") {
    return Response.error("[Cerebras] Chưa nhập API Key. Vào cài đặt extension để nhập.");
  }

  var langMap = {
    "vi": "Vietnamese", "en": "English",
    "zh": "Chinese",    "ja": "Japanese", "ko": "Korean"
  };
  var srcName  = langMap[fromLang] || fromLang;
  var destName = langMap[toLang]   || toLang;

  var sysPrompt =
    "You are a professional novel translator. " +
    "Translate the following text from " + srcName + " to " + destName + ". " +
    "Return ONLY the translated text. No explanations, no notes, no original text.";

  var response;
  try {
    response = fetch("https://api.cerebras.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apiKey.trim()
      },
      body: JSON.stringify({
        model: model.trim(),
        max_tokens: 8192,
        temperature: temp,
        messages: [
          { role: "system", content: sysPrompt },
          { role: "user",   content: text }
        ]
      })
    });
  } catch (e) {
    return Response.error("[Cerebras] Lỗi kết nối: " + e.toString());
  }

  // Kiểm tra HTTP status
  if (!response.ok) {
    var errBody = "";
    try { errBody = response.text(); } catch(e2) {}
    return Response.error("[Cerebras] HTTP " + response.status + ": " + errBody.substring(0, 300));
  }

  // Parse JSON response
  var data;
  try {
    data = response.json();
  } catch (e) {
    var raw = "";
    try { raw = response.text(); } catch(e2) {}
    return Response.error("[Cerebras] Lỗi parse JSON: " + raw.substring(0, 200));
  }

  // Lỗi từ API Cerebras
  if (data.error) {
    var msg = (data.error.message) ? data.error.message : JSON.stringify(data.error);
    return Response.error("[Cerebras] API lỗi: " + msg);
  }

  // Lấy text dịch
  var result = "";
  try {
    result = data.choices[0].message.content;
  } catch (e) {
    return Response.error("[Cerebras] Không đọc được kết quả: " + JSON.stringify(data).substring(0, 200));
  }

  if (!result || result.trim() === "") {
    return Response.error("[Cerebras] Kết quả dịch rỗng.");
  }

  return Response.success(result.trim());
}
