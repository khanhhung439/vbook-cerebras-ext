// =============================================
// Cerebras AI Translate - Vbook Extension
// Hỗ trợ: multi-model, prompt tùy chỉnh,
//         từ điển, kho tên nhân vật theo truyện
// =============================================

function execute(content, config) {
  // --- Đọc config ---
  var apiKey      = (config.api_keys || "").trim();
  var temperature = parseFloat(config.temp) || 0.5;
  var topP        = parseFloat(config.topP) || 0.7;
  var useDic      = parseInt(config.use_vb_basic_dic) || 1;
  var listprompts = (config.listprompts || "").trim();
  var nameKey     = (config.name_key   || "").trim(); // key kho tên truyện hiện tại

  // Lấy model đầu tiên trong danh sách
  var modelRaw = (config.modelsavecache || "qwen-3-235b-a22b-instruct-2507").trim();
  var models   = modelRaw.split("\n").map(function(m){ return m.trim(); }).filter(function(m){ return m.length > 0; });
  var model    = models[0] || "qwen-3-235b-a22b-instruct-2507";

  // --- Kiểm tra API key ---
  if (!apiKey || apiKey.length < 10) {
    return Response.error("Chưa nhập API Key! Lấy miễn phí tại cloud.cerebras.ai");
  }

  // --- Đọc bộ nhớ cục bộ ---
  var basicDic    = (useDic === 1) ? (LocalStorage.get("vb_basic_dic")       || "") : "";
  var stopWordDic = LocalStorage.get("vb_stopWord_dic")   || "";
  var hoBoSung    = LocalStorage.get("vb_Ho_bo_sung")     || "";
  var hauToBoSung = LocalStorage.get("vb_Hau_to_bo_sung") || "";

  // --- Đọc kho tên nhân vật ---
  // Ưu tiên: NAME_{name_key} → NAME_tieuchuan (mặc định)
  var nameDic = "";
  if (nameKey.length > 0) {
    nameDic = LocalStorage.get("NAME_" + nameKey) || "";
  }
  if (nameDic.length === 0) {
    nameDic = LocalStorage.get("NAME_tieuchuan") || "";
  }

  // --- Xây dựng phần từ điển cho prompt ---
  var dicSection = "";

  // Kho tên nhân vật (ưu tiên cao nhất)
  if (nameDic.length > 0) {
    dicSection += "\n\nKHO TÊN NHÂN VẬT (bắt buộc dùng đúng, không được dịch khác):\n" + nameDic + "\n";
    dicSection += "Định dạng: Tên_gốc=Tên_tiếng_Việt. Ví dụ: 林枫=Lâm Phong\n";
  }

  // Từ điển cơ bản
  if (basicDic.length > 0 || stopWordDic.length > 0) {
    dicSection += "\nTỪ ĐIỂN BỔ SUNG:\n";
    if (stopWordDic) dicSection += stopWordDic + "\n";
    if (basicDic)    dicSection += basicDic    + "\n";
  }

  // Gợi ý nhận diện tên
  if (hoBoSung.length > 0 || hauToBoSung.length > 0) {
    dicSection += "\nNHẬN DIỆN TÊN NHÂN VẬT MỚI:\n";
    if (hoBoSung)    dicSection += "- Họ thường gặp: "    + hoBoSung    + "\n";
    if (hauToBoSung) dicSection += "- Hậu tố thường gặp: " + hauToBoSung + "\n";
  }

  // --- Chọn prompt ---
  var systemPrompt = "";
  if (listprompts.length > 0) {
    var promptNames = listprompts.split("\n").map(function(p){ return p.trim(); }).filter(function(p){ return p.length > 0; });
    if (promptNames.length > 0) {
      var saved = LocalStorage.get("PROMPT_" + promptNames[0]) || "";
      if (saved.length > 10) systemPrompt = saved;
    }
  }

  if (systemPrompt.length === 0) {
    systemPrompt =
      "Bạn là chuyên gia dịch thuật truyện sang tiếng Việt.\n\n" +
      "QUY TẮC:\n" +
      "1. Dịch tự nhiên, trôi chảy, đúng văn phong truyện chữ Việt Nam\n" +
      "2. Ưu tiên tuyệt đối kho tên nhân vật đã cho - không được tự ý dịch khác\n" +
      "3. Tên chưa có trong kho: phiên âm Hán Việt, giữ nhất quán trong toàn đoạn\n" +
      "4. Giữ nguyên cấu trúc đoạn văn và dấu xuống dòng\n" +
      "5. Dịch đầy đủ, không bỏ sót nội dung\n" +
      "6. Chỉ trả về bản dịch, KHÔNG giải thích, KHÔNG ghi chú\n" +
      "7. Xưng hô phù hợp vai vế nhân vật";
  }

  systemPrompt += dicSection;

  // --- Gọi API Cerebras ---
  var response = fetch("https://api.cerebras.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apiKey
    },
    body: {
      model: model,
      temperature: temperature,
      top_p: topP,
      max_completion_tokens: 16000,
      stream: false,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user",   content: "Dịch sang tiếng Việt:\n\n" + content }
      ]
    }
  });

  // --- Xử lý lỗi HTTP ---
  if (!response.ok) {
    var s = response.status;
    if (s === 401) return Response.error("API Key không hợp lệ! Kiểm tra tại cloud.cerebras.ai");
    if (s === 429) return Response.error("Quá giới hạn request! Thử lại sau vài giây.");
    if (s === 400) return Response.error("Lỗi tham số (400). Kiểm tra tên model: " + model);
    if (s === 503) return Response.error("Server Cerebras bận. Thử lại sau.");
    return Response.error("Lỗi HTTP " + s + ". Thử lại sau.");
  }

  // --- Parse kết quả ---
  var json = response.json();
  if (!json || !json.choices || json.choices.length === 0) {
    return Response.error("API không trả về kết quả. Thử lại sau.");
  }

  var translated = json.choices[0].message.content;
  if (!translated || translated.trim().length === 0) {
    return Response.error("Bản dịch trống. Thử lại sau.");
  }

  return Response.success(translated.trim());
}
