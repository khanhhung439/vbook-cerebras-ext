function execute(text, fromLang, toLang) {
  // --- Đọc config ---
  var apiKey = config["api_key"] || config["api_keys"] || "";
  var model  = config["model"]   || "qwen-3-32b";
  var temp   = parseFloat(config["temp"] || "0.3");

  // --- Kiểm tra API key ---
  if (!apiKey || apiKey === "") {
    return Response.error("Chưa nhập API Key. Vào Settings của extension để nhập.");
  }

  // --- Xây prompt ---
  var langMap = {
    "vi": "Vietnamese", "en": "English",
    "zh": "Chinese",    "ja": "Japanese", "ko": "Korean"
  };
  var targetName = langMap[toLang] || toLang;
  var sourceName = langMap[fromLang] || fromLang;

  var systemPrompt =
    "You are a professional novel translator. " +
    "Translate the text from " + sourceName + " to " + targetName + ". " +
    "Output ONLY the translated text, no explanations, no notes, no original text.";

  var userPrompt = text;

  // --- Gọi API ---
  var url = "https://api.cerebras.ai/v1/chat/completions";

  var bodyObj = {
    model: model,
    max_tokens: 8192,
    temperature: temp,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user",   content: userPrompt   }
    ]
  };

  var response;
  try {
    response = fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apiKey
      },
      body: JSON.stringify(bodyObj)
    });
  } catch (fetchErr) {
    return Response.error("Lỗi kết nối mạng: " + fetchErr.toString());
  }

  // --- Kiểm tra HTTP status ---
  var statusCode = 0;
  try {
    statusCode = response.code;
  } catch(e) {
    statusCode = 0;
  }

  // --- Đọc body ---
  var rawBody = "";
  try {
    rawBody = response.body;
  } catch(e) {
    rawBody = "";
  }

  if (!rawBody || rawBody === "") {
    return Response.error("API trả về rỗng (HTTP " + statusCode + "). Kiểm tra API Key.");
  }

  // --- Parse JSON ---
  var data;
  try {
    data = JSON.parse(rawBody);
  } catch (parseErr) {
    return Response.error("Lỗi parse JSON (HTTP " + statusCode + "): " + rawBody.substring(0, 200));
  }

  // --- Xử lý lỗi từ API ---
  if (data.error) {
    var errMsg = data.error.message || JSON.stringify(data.error);
    return Response.error("API lỗi: " + errMsg);
  }

  // --- Lấy kết quả ---
  var translated = "";
  try {
    translated = data.choices[0].message.content;
  } catch (e) {
    return Response.error("Không đọc được kết quả. Response: " + rawBody.substring(0, 300));
  }

  if (!translated || translated === "") {
    return Response.error("Dịch thành công nhưng kết quả rỗng.");
  }

  return Response.success(translated);
}
