function execute(text, fromLang, toLang) {
    if (!text || text.trim() === "") return Response.error("Lỗi: Văn bản trống");
    return translateContent(text, fromLang, toLang, 0);
}

function translateContent(text, fromLang, toLang, retryCount) {
    if (retryCount > 2) return Response.error("Thất bại sau 3 lần thử");

    // Đọc API key từ config
    var apiKeysRaw = "";
    try {
        if (typeof config !== "undefined" && config !== null && config["api_keys"]) {
            apiKeysRaw = config["api_keys"].trim();
        }
    } catch(e) {}

    if (!apiKeysRaw || apiKeysRaw.length < 10) {
        return Response.error("LỖI: Chưa có API Key. config=" + (typeof config));
    }

    // Chọn key ngẫu nhiên
    var apiKeys = [];
    var lines = apiKeysRaw.split("\n");
    for (var i = 0; i < lines.length; i++) {
        var k = lines[i].trim();
        if (k.length > 10) apiKeys.push(k);
    }
    if (apiKeys.length === 0) return Response.error("LỖI: Không tìm thấy API Key hợp lệ");
    var apiKey = apiKeys[Math.floor(Math.random() * apiKeys.length)];

    // Đọc model
    var modelRaw = "";
    try {
        if (typeof config !== "undefined" && config !== null && config["modelsavecache"]) {
            modelRaw = config["modelsavecache"].trim();
        }
    } catch(e) {}
    var model = "qwen-3-235b-a22b-instruct-2507";
    if (modelRaw.length > 0) {
        var mlines = modelRaw.split("\n");
        if (mlines[0].trim().length > 0) model = mlines[0].trim();
    }

    // Đọc temperature
    var temperature = 0.5;
    var topP = 0.7;
    try {
        if (typeof config !== "undefined" && config !== null) {
            if (config["temp"]) temperature = parseFloat(config["temp"]) || 0.5;
            if (config["topP"]) topP = parseFloat(config["topP"]) || 0.7;
        }
    } catch(e) {}

    // Đọc localStorage
    var nameKey = "tieuchuan";
    var listprompts = "";
    var useDic = 1;
    try {
        if (typeof config !== "undefined" && config !== null) {
            if (config["name_key"]) nameKey = config["name_key"].trim();
            if (config["listprompts"]) listprompts = config["listprompts"].trim();
            if (config["use_vb_basic_dic"]) useDic = parseInt(config["use_vb_basic_dic"]) || 1;
        }
    } catch(e) {}

    var nameDic = "";
    var basicDic = "";
    var stopWordDic = "";
    try {
        nameDic = localStorage.getItem("NAME_" + nameKey) || localStorage.getItem("NAME_tieuchuan") || "";
        if (useDic === 1) basicDic = localStorage.getItem("vb_basic_dic") || "";
        stopWordDic = localStorage.getItem("vb_stopWord_dic") || "";
    } catch(e) {}

    // Ngôn ngữ nguồn
    var langNames = { "zh": "Trung", "en": "Anh", "ja": "Nhật", "ko": "Hàn", "fr": "Pháp", "de": "Đức", "ru": "Nga" };
    var fromName = (fromLang && langNames[fromLang]) ? langNames[fromLang] : "Trung";

    // Prompt
    var systemPrompt = "";
    try {
        if (listprompts.length > 0) {
            var pn = listprompts.split("\n")[0].trim();
            if (pn.length > 0) systemPrompt = localStorage.getItem("PROMPT_" + pn) || "";
        }
    } catch(e) {}

    if (!systemPrompt || systemPrompt.length === 0) {
        systemPrompt =
            "Bạn là chuyên gia dịch thuật truyện từ tiếng " + fromName + " sang tiếng Việt.\n" +
            "QUY TẮC:\n" +
            "1. Dịch tự nhiên, trôi chảy, đúng văn phong truyện Việt Nam\n" +
            "2. Ưu tiên kho tên nhân vật - không tự ý dịch khác\n" +
            "3. Giữ nguyên cấu trúc đoạn văn và xuống dòng\n" +
            "4. Dịch đầy đủ, không bỏ sót\n" +
            "5. Chỉ trả về bản dịch, KHÔNG ghi chú thêm";
    }
    if (nameDic.length > 0) systemPrompt += "\n\nKHO TÊN NHÂN VẬT:\n" + nameDic;
    if (stopWordDic.length > 0 || basicDic.length > 0) {
        systemPrompt += "\n\nTỪ ĐIỂN:\n" + stopWordDic + "\n" + basicDic;
    }

    // Gọi API
    var response;
    try {
        response = fetch("https://api.cerebras.ai/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apiKey
            },
            body: JSON.stringify({
                model: model,
                temperature: temperature,
                top_p: topP,
                max_completion_tokens: 16000,
                stream: false,
                messages: [
                    { role: "system", content: systemPrompt },
                    { role: "user", content: "Dịch sang tiếng Việt:\n\n" + text }
                ]
            })
        });
    } catch(e) {
        return Response.error("LỖI fetch: " + e.toString());
    }

    if (!response.ok) {
        var s = response.status;
        var errText = "";
        try { errText = response.text().substring(0, 200); } catch(e2) {}
        if (s === 401) return Response.error("LỖI 401: API Key sai. Key=" + apiKey.substring(0,10) + "...");
        if (s === 429) {
            sleep(2000);
            return translateContent(text, fromLang, toLang, retryCount + 1);
        }
        return Response.error("LỖI HTTP " + s + ": " + errText);
    }

    var json;
    try { json = response.json(); } catch(e) {
        return Response.error("LỖI parse JSON: " + e.toString());
    }

    if (!json || !json.choices || json.choices.length === 0) {
        return Response.error("LỖI: API không trả về choices. Response=" + JSON.stringify(json).substring(0,200));
    }

    var translated = json.choices[0].message.content;
    if (!translated || translated.trim().length === 0) {
        return Response.error("LỖI: Bản dịch trống");
    }

    return Response.success(translated.trim());
}
