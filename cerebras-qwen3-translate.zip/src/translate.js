function execute(text, fromLang, toLang) {
  var apiKey = config["api_keys"] || "MISSING";
  var model  = config["model"]    || "gpt-oss-120b";

  // Thử gọi API với đoạn text ngắn để test
  var response;
  try {
    response = fetch("https://api.cerebras.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apiKey.trim()
      },
      body: JSON.stringify({
        model: model,
        max_tokens: 50,
        temperature: 0.3,
        messages: [
          { role: "user", content: "Reply with just the word: WORKING" }
        ]
      })
    });
  } catch (e) {
    return Response.error("FETCH_ERROR\nkey_prefix=" + apiKey.substring(0,8) + "\nmodel=" + model + "\nerr=" + e.toString());
  }

  // Đọc raw text dù success hay fail
  var rawText = "";
  try { rawText = response.text(); } catch(e2) { rawText = "cant_read_body"; }

  if (!response.ok) {
    return Response.error("HTTP_" + response.status + "\nmodel=" + model + "\nbody=" + rawText.substring(0, 300));
  }

  // Parse JSON
  var data;
  try {
    data = JSON.parse(rawText);
  } catch(e) {
    return Response.error("JSON_PARSE_FAIL\n" + rawText.substring(0, 300));
  }

  if (data.error) {
    return Response.error("API_ERROR: " + (data.error.message || JSON.stringify(data.error)));
  }

  var testResult = "";
  try { testResult = data.choices[0].message.content; } catch(e) { testResult = "no_choices"; }

  // Nếu test OK thì dịch thật
  if (testResult.indexOf("WORKING") >= 0 || testResult.length > 0) {
    var langMap = {
      "vi": "Vietnamese", "en": "English",
      "zh": "Chinese",    "ja": "Japanese", "ko": "Korean"
    };
    var response2;
    try {
      response2 = fetch("https://api.cerebras.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + apiKey.trim()
        },
        body: JSON.stringify({
          model: model,
          max_tokens: 8192,
          temperature: 0.3,
          messages: [
            {
              role: "system",
              content: "You are a professional novel translator. Translate from " +
                (langMap[fromLang] || fromLang) + " to " + (langMap[toLang] || toLang) +
                ". Return ONLY the translated text."
            },
            { role: "user", content: text }
          ]
        })
      });
    } catch(e) {
      return Response.error("TRANSLATE_FETCH_ERROR: " + e.toString());
    }

    if (!response2.ok) {
      var b = "";
      try { b = response2.text(); } catch(e) {}
      return Response.error("TRANSLATE_HTTP_" + response2.status + ": " + b.substring(0,200));
    }

    var data2;
    try { data2 = response2.json(); } catch(e) {
      return Response.error("TRANSLATE_JSON_FAIL");
    }

    var result = "";
    try { result = data2.choices[0].message.content; } catch(e) {
      return Response.error("TRANSLATE_NO_CONTENT: " + JSON.stringify(data2).substring(0,200));
    }

    return Response.success(result.trim());
  }

  return Response.error("TEST_UNEXPECTED: " + testResult);
}
