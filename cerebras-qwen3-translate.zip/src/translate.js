// Cerebras Qwen3 Translate - Vbook Extension
// Dựa trên phân tích IPA: settingData = Map<String,String> inject qua config object
// LocalStorage riêng biệt qua localStorage.getItem/setItem
// Runtime: Rhino 1.7.14

function execute(text, fromLang, toLang) {
    if (!text || text.trim() === "") {
        return Response.error("Không có văn bản để dịch");
    }
    return translateContent(text, fromLang, toLang, 0);
}

function translateContent(text, fromLang, toLang, retryCount) {
    if (retryCount > 2) {
        return Response.error("Thất bại sau 3 lần thử. Kiểm tra API Key và kết nối mạng.");
    }

    // === ĐỌC SETTING (settingData từ config trong plugin.json) ===
    // Vbook inject settingData qua biến toàn cục "config" hoặc "setting"
    var apiKeysRaw = "";
    var modelRaw = "qwen-3-235b-a22b-instruct-2507";
    var temperature = 0.5;
    var topP = 0.7;
    var nameKey = "tieuchuan";
    var listprompts = "";
    var useDic = 1;

    // Thử đọc từ config object (cách Vbook inject settingData)
    try {
        if (typeof config !== "undefined" && config !== null) {
            if (config["api_keys"]) apiKeysRaw = config["api_keys"];
            if (config["modelsavecache"]) modelRaw = config["modelsavecache"];
            if (config["temp"]) temperature = parseFloat(config["temp"]) || 0.5;
            if (config["topP"]) topP = parseFloat(config["topP"]) || 0.7;
            if (config["name_key"]) nameKey = config["name_key"];
            if (config["listprompts"]) listprompts = config["listprompts"];
            if (config["use_vb_basic_dic"]) useDic = parseInt(config["use_vb_basic_dic"]) || 1;
        }
    } catch(e) {}

    // Fallback: đọc từ localStorage nếu không có config
    if (!apiKeysRaw || apiKeysRaw.trim().length < 10) {
        try { apiKeysRaw = localStorage.getItem("cerebras_api_keys") || ""; } catch(e) {}
    }
    if (!apiKeysRaw || apiKeysRaw.trim().length < 10) {
        return Response.error("Chưa nhập API Key! Vào Cài đặt ext → Cerebras API Key");
    }

    // === CHỌN API KEY (hỗ trợ nhiều key) ===
    var apiKeys = [];
    var rawLines = apiKeysRaw.trim().split("\n");
    for (var i = 0; i < rawLines.length; i++) {
        var k = rawLines[i].trim();
        if (k.length > 10) apiKeys.push(k);
    }
    if (apiKeys.length === 0) {
        return Response.error("API Key không hợp lệ! Kiểm tra lại.");
    }
    var apiKey = apiKeys[Math.floor(Math.random() * apiKeys.length)];

    // === CHỌN MODEL (dòng đầu trong danh sách) ===
    var modelLines = modelRaw.trim().split("\n");
    var model = modelLines[0].trim() || "qwen-3-235b-a22b-instruct-2507";

    // === ĐỌC LOCALSTORAGE (kho tên, từ điển) ===
    var nameDic = "";
    var basicDic = "";
    var stopWordDic = "";
    var hoBoSung = "";
    var hauToBoSung = "";

    try {
        var nk = nameKey.trim();
        if (nk.length > 0) nameDic = localStorage.getItem("NAME_" + nk) || "";
        if (!nameDic) nameDic = localStorage.getItem("NAME_tieuchuan") || "";
    } catch(e) {}

    try {
        if (useDic === 1) basicDic = localStorage.getItem("vb_basic_dic") || "";
        stopWordDic = localStorage.getItem("vb_stopWord_dic") || "";
        hoBoSung    = localStorage.getItem("vb_Ho_bo_sung") || "";
        hauToBoSung = localStorage.getItem("vb_Hau_to_bo_sung") || "";
    } catch(e) {}

    // === XÁC ĐỊNH NGÔN NGỮ NGUỒN ===
    var langNames = {
        "zh": "Trung", "en": "Anh", "ja": "Nhật",
        "ko": "Hàn", "fr": "Pháp", "de": "Đức",
        "ru": "Nga", "es": "Tây Ban Nha", "vi": "Việt"
    };
    var fromName = (fromLang && langNames[fromLang]) ? langNames[fromLang] : "Trung";

    // === CHỌN PROMPT ===
    var systemPrompt = "";
    try {
        if (listprompts && listprompts.trim().length > 0) {
            var pnames = listprompts.trim().split("\n");
            for (var pi = 0; pi < pnames.length; pi++) {
                var pn = pnames[pi].trim();
                if (pn.length > 0) {
                    var saved = localStorage.getItem("PROMPT_" + pn) || "";
                    if (saved.length > 10) { systemPrompt = saved; break; }
                }
            }
        }
    } catch(e) {}

    if (!systemPrompt || systemPrompt.length === 0) {
        systemPrompt =
            "Bạn là chuyên gia dịch thuật truyện từ tiếng " + fromName + " sang tiếng Việt.\n\n" +
            "QUY TẮC:\n" +
            "1. Dịch tự nhiên, trôi chảy, đúng văn phong truyện chữ Việt Nam\n" +
            "2. Ưu tiên tuyệt đối kho tên nhân vật đã cho - không tự ý dịch khác\n" +
            "3. Tên chưa có trong kho: phiên âm Hán Việt, giữ nhất quán trong đoạn\n" +
            "4. Giữ nguyên cấu trúc đoạn văn và dấu xuống dòng\n" +
            "5. Dịch đầy đủ, không bỏ sót nội dung\n" +
            "6. Chỉ trả về bản dịch, KHÔNG giải thích, KHÔNG ghi chú\n" +
            "7. Xưng hô phù hợp vai vế nhân vật";
    }

    // Thêm kho tên và từ điển vào prompt
    if (nameDic && nameDic.length > 0) {
        systemPrompt += "\n\nKHO TÊN NHÂN VẬT (bắt buộc dùng đúng, không dịch khác):\n" + nameDic;
    }
    if ((stopWordDic && stopWordDic.length > 0) || (basicDic && basicDic.length > 0)) {
        systemPrompt += "\n\nTỪ ĐIỂN BỔ SUNG:\n";
        if (stopWordDic) systemPrompt += stopWordDic + "\n";
        if (basicDic) systemPrompt += basicDic;
    }
    if ((hoBoSung && hoBoSung.length > 0) || (hauToBoSung && hauToBoSung.length > 0)) {
        systemPrompt += "\n\nNHẬN DIỆN TÊN NHÂN VẬT MỚI:\n";
        if (hoBoSung) systemPrompt += "- Họ thường gặp: " + hoBoSung + "\n";
        if (hauToBoSung) systemPrompt += "- Hậu tố thường gặp: " + hauToBoSung;
    }

    // === GỌI API CEREBRAS ===
    var response;
    try {
        response = fetch("https://api.cerebras.ai/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apiKey
            },
            body: JSON.stringify({
                model: model,
                temperature: temperature,
                top_p: topP,
                max_completion_tokens: 16000,
                stream: false,
                messages: [
                    { role: "system", content: systemPrompt },
                    { role: "user",   content: "Dịch sang tiếng Việt:\n\n" + text }
                ]
            })
        });
    } catch(e) {
        Console.log("Cerebras fetch error: " + e.toString());
        return translateContent(text, fromLang, toLang, retryCount + 1);
    }

    // === XỬ LÝ LỖI HTTP ===
    if (!response.ok) {
        var s = response.status;
        Console.log("Cerebras HTTP error: " + s);
        if (s === 401) return Response.error("API Key không hợp lệ! Kiểm tra tại cloud.cerebras.ai");
        if (s === 429) {
            sleep(2000);
            return translateContent(text, fromLang, toLang, retryCount + 1);
        }
        if (s === 503 || s === 502) {
            sleep(1000);
            return translateContent(text, fromLang, toLang, retryCount + 1);
        }
        if (s === 400) {
            var errBody = "";
            try { errBody = response.text(); } catch(e2) {}
            Console.log("400 body: " + errBody);
            return Response.error("Lỗi model: " + model + ". " + errBody);
        }
        return Response.error("Lỗi HTTP " + s + ". Thử lại sau.");
    }

    // === PARSE KẾT QUẢ ===
    var json;
    try {
        json = response.json();
    } catch(e) {
        Console.log("JSON parse error: " + e.toString());
        return translateContent(text, fromLang, toLang, retryCount + 1);
    }

    if (!json || !json.choices || json.choices.length === 0) {
        Console.log("No choices in response");
        return translateContent(text, fromLang, toLang, retryCount + 1);
    }

    var translated = json.choices[0].message.content;
    if (!translated || translated.trim().length === 0) {
        Console.log("Empty translation");
        return translateContent(text, fromLang, toLang, retryCount + 1);
    }

    return Response.success(translated.trim());
}
