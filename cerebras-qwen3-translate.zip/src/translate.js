function execute(content, config) {
  var apiKey      = (config.api_keys || "").trim();
  var temperature = parseFloat(config.temp) || 0.5;
  var topP        = parseFloat(config.topP) || 0.7;
  var useDic      = parseInt(config.use_vb_basic_dic) || 1;
  var listprompts = (config.listprompts || "").trim();
  var nameKey     = (config.name_key || "tieuchuan").trim();

  // Parse model: lấy dòng đầu tiên, extract model ID (từ cuối sau khoảng trắng)
  var modelRaw = (config.modelsavecache || "qwen-3-235b-a22b-instruct-2507").trim();
  var firstLine = modelRaw.split("\n")[0].trim();
  // Nếu có khoảng trắng → lấy từ cuối (model ID)
  var parts = firstLine.split(" ");
  var model = parts[parts.length - 1] || "qwen-3-235b-a22b-instruct-2507";

  if (!apiKey || apiKey.length < 10) {
    return Response.error("Chưa nhập API Key! Lấy miễn phí tại cloud.cerebras.ai");
  }

  // Đọc bộ nhớ cục bộ
  var basicDic    = (useDic === 1) ? (LocalStorage.get("vb_basic_dic") || "") : "";
  var stopWordDic = LocalStorage.get("vb_stopWord_dic")   || "";
  var hoBoSung    = LocalStorage.get("vb_Ho_bo_sung")     || "";
  var hauToBoSung = LocalStorage.get("vb_Hau_to_bo_sung") || "";

  // Kho tên nhân vật
  var nameDic = "";
  if (nameKey.length > 0) nameDic = LocalStorage.get("NAME_" + nameKey) || "";
  if (nameDic.length === 0) nameDic = LocalStorage.get("NAME_tieuchuan") || "";

  // Xây dựng từ điển cho prompt
  var dicSection = "";
  if (nameDic.length > 0) {
    dicSection += "\n\nKHO TÊN NHÂN VẬT (bắt buộc dùng đúng):\n" + nameDic + "\n";
  }
  if (basicDic.length > 0 || stopWordDic.length > 0) {
    dicSection += "\nTỪ ĐIỂN BỔ SUNG:\n";
    if (stopWordDic) dicSection += stopWordDic + "\n";
    if (basicDic)    dicSection += basicDic    + "\n";
  }
  if (hoBoSung.length > 0 || hauToBoSung.length > 0) {
    dicSection += "\nNHẬN DIỆN TÊN MỚI:\n";
    if (hoBoSung)    dicSection += "- Họ: "    + hoBoSung    + "\n";
    if (hauToBoSung) dicSection += "- Hậu tố: " + hauToBoSung + "\n";
  }

  // Chọn prompt
  var systemPrompt = "";
  if (listprompts.length > 0) {
    var pname = listprompts.split("\n")[0].trim();
    var saved = LocalStorage.get("PROMPT_" + pname) || "";
    if (saved.length > 10) systemPrompt = saved;
  }
  if (systemPrompt.length === 0) {
    systemPrompt =
      "Bạn là chuyên gia dịch thuật truyện sang tiếng Việt.\n\n" +
      "QUY TẮC:\n" +
      "1. Dịch tự nhiên, trôi chảy, đúng văn phong truyện chữ Việt Nam\n" +
      "2. Ưu tiên tuyệt đối kho tên nhân vật đã cho\n" +
      "3. Tên chưa có trong kho: phiên âm Hán Việt, giữ nhất quán\n" +
      "4. Giữ nguyên cấu trúc đoạn văn và xuống dòng\n" +
      "5. Dịch đầy đủ, không bỏ sót\n" +
      "6. Chỉ trả về bản dịch, KHÔNG ghi chú thêm\n" +
      "7. Xưng hô phù hợp vai vế nhân vật";
  }
  systemPrompt += dicSection;

  // Gọi API
  var response = fetch("https://api.cerebras.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apiKey
    },
    body: {
      model: model,
      temperature: temperature,
      top_p: topP,
      max_completion_tokens: 16000,
      stream: false,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user",   content: "Dịch sang tiếng Việt:\n\n" + content }
      ]
    }
  });

  if (!response.ok) {
    var s = response.status;
    if (s === 401) return Response.error("API Key không hợp lệ!");
    if (s === 429) return Response.error("Quá giới hạn! Thử lại sau.");
    if (s === 400) return Response.error("Lỗi model: " + model);
    if (s === 503) return Response.error("Server bận. Thử lại sau.");
    return Response.error("Lỗi HTTP " + s);
  }

  var json = response.json();
  if (!json || !json.choices || json.choices.length === 0) {
    return Response.error("Không có kết quả. Thử lại.");
  }

  var translated = json.choices[0].message.content;
  if (!translated || translated.trim().length === 0) {
    return Response.error("Bản dịch trống. Thử lại.");
  }

  return Response.success(translated.trim());
}
