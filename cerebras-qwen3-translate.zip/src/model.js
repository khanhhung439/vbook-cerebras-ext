function execute() {
  var models = [
    { id: "qwen-3-32b", name: "Qwen3 32B (Khuyên dùng)" },
    { id: "qwen-3-8b", name: "Qwen3 8B (Nhanh hơn)" },
    { id: "llama-4-scout-17b-16e-instruct", name: "Llama 4 Scout 17B" },
    { id: "llama-3.3-70b", name: "Llama 3.3 70B" }
  ];
  return Response.success(models);
}
