function execute() {
  return Response.success([
    { id: "gpt-oss-120b",                    name: "GPT-OSS 120B ⭐ (Production, mạnh nhất)" },
    { id: "llama3.1-8b",                     name: "Llama 3.1 8B ⚡ (Production, nhanh nhất)" },
    { id: "zai-glm-4.7",                     name: "GLM 4.7 355B 🔬 (Preview)" },
    { id: "qwen-3-235b-a22b-instruct-2507",  name: "Qwen3 235B 🔬 (Preview)" }
  ]);
}
