// model.js - Vbook gọi execute() để lấy danh sách model hiển thị trong dropdown
function execute() {
    return Response.success([
        { id: "qwen-3-235b-a22b-instruct-2507", name: "Qwen3 235B (Mạnh nhất)" },
        { id: "llama3.1-8b",                    name: "Llama 3.1 8B (Nhanh nhất)" },
        { id: "gpt-oss-120b",                   name: "GPT OSS 120B (Cân bằng)" }
    ]);
}
