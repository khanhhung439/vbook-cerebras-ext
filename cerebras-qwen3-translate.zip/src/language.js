// language.js - Vbook gọi execute() để lấy danh sách ngôn ngữ hỗ trợ
function execute() {
    return Response.success([
        { id: "vi",  name: "Việt" },
        { id: "zh",  name: "Trung" },
        { id: "en",  name: "Anh" },
        { id: "ja",  name: "Nhật" },
        { id: "ko",  name: "Hàn" },
        { id: "fr",  name: "Pháp" },
        { id: "de",  name: "Đức" },
        { id: "ru",  name: "Nga" },
        { id: "es",  name: "Tây Ban Nha" },
        { id: "th",  name: "Thái" },
        { id: "ar",  name: "Ả Rập" }
    ]);
}
