function execute() {
  return Response.success([
    { code: "vi",    name: "Việt" },
    { code: "zh-CN", name: "Trung" },
    { code: "en",    name: "Anh" },
    { code: "ja",    name: "Nhật" },
    { code: "ko",    name: "Hàn" }
  ]);
}
