let languages = [
    {"id": "vi"},
    {"id": "zh"},
    {"id": "en"},
    {"id": "ja"},
    {"id": "ko"},
    {"id": "fr"},
    {"id": "de"},
    {"id": "ru"},
    {"id": "es"},
    {"id": "pt"},
    {"id": "th"},
    {"id": "ar"}
]
